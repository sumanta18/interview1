﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace Maersk.Sorting.Api.Controllers
{
    [ApiController]
    [Route("sort")]
    public class SortController : ControllerBase
    {
        private readonly ISortJobProcessor _sortJobProcessor;
        public Dictionary<Guid, SortJob> listofJobs = new Dictionary<Guid, SortJob>();
        public SortController(ISortJobProcessor sortJobProcessor)
        {
            _sortJobProcessor = sortJobProcessor;
           
        }

        [HttpPost("run")]
        [Obsolete("This executes the sort job asynchronously. Use the asynchronous 'EnqueueJob' instead.")]
        public async Task<ActionResult<SortJob>> EnqueueAndRunJob(int[] values)
        {
            var pendingJob = new SortJob(
                id: Guid.NewGuid(),
                status: SortJobStatus.Pending,
                duration: null,
                input: values,
                output: null);

            var completedJob = await _sortJobProcessor.Process(pendingJob);

            return Ok(completedJob);
        }

        [HttpPost]
        public Task<ActionResult<SortJob>> EnqueueJob(int[] values)
        {

            // TODO: Should enqueue a job to be processed in the background.
                      
            var pendingJob = new SortJob(
               id: Guid.NewGuid(),
               status: SortJobStatus.Pending,
               duration: null,
               input: values,
               output: null);

           
            return (Task<ActionResult<SortJob>>)Task.Run(() =>
            {
                listofJobs.Add(pendingJob.Id, pendingJob);               
                
            });


        }

        [HttpGet]
        public Task<ActionResult<SortJob[]>> GetJobs()
        {
            // TODO: Should return all jobs that have been enqueued (both pending and completed).
            return (Task<ActionResult<SortJob[]>>)Task.Run(() =>
            {
                var listSortJob= listofJobs;

            });

        }

        [HttpGet("{jobId}")]
        public Task<ActionResult<SortJob>> GetJob(Guid jobId)
        {
            // TODO: Should return a specific job by ID.
            return (Task<ActionResult<SortJob>>)Task.Run(() =>
            {
                SortJob sortJob = listofJobs[jobId];

            });
            
        }

        [HttpPost("RunJob")]
        public async void RunJob()
        {
            foreach (var item in listofJobs)
            {
                 await _sortJobProcessor.Process(item.Value);
            }

        }
    }
}
